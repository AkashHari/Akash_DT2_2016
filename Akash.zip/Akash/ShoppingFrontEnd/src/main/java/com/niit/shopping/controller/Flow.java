package com.niit.shopping.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class Flow {

@RequestMapping("/fruit")
public ModelAndView tofruit()
{
	return new ModelAndView("fruit");
}

@RequestMapping("/checkout")
public ModelAndView tocheckout()
{
	return new ModelAndView("checkout");
}

@RequestMapping("/choco")
public ModelAndView tochoco()
{
	return new ModelAndView("choco");
}

@RequestMapping("/confect")
public ModelAndView toconfect()
{
	return new ModelAndView("confect");
}

@RequestMapping("/dessert")
public ModelAndView todessert()
{
	return new ModelAndView("dessert");
}

@RequestMapping("/health")
public ModelAndView tohealth()
{
	return new ModelAndView("health");
}

@RequestMapping("/icecream")
public ModelAndView toicecream()
{
	return new ModelAndView("icecream");
}

@RequestMapping("/index")
public ModelAndView toindex()
{
	return new ModelAndView("index");
}

@RequestMapping("/index1")
public ModelAndView toindex1()
{
	return new ModelAndView("index1");
}


@RequestMapping("/login")
public ModelAndView tologin()
{
	return new ModelAndView("login");
}

@RequestMapping("/mail")
public ModelAndView tomail()
{
	return new ModelAndView("mail");
}

@RequestMapping("/patis")
public ModelAndView topatis()
{
	return new ModelAndView("patis");
}

@RequestMapping("/register")
public ModelAndView toregister()
{
	return new ModelAndView("register");
}

@RequestMapping("/single")
public ModelAndView tosingle()
{
	return new ModelAndView("single");
}



}




